

public class dados {

	
	// Ordenar una lista: insercion directa
	public static void ordenar (int [] lista){
		for (int i=1; i<lista.length; i++){
			int auxiliar = lista[i];
			int j=i-1;
			while (j>=0 && auxiliar<lista[j]){
				lista [j+1]=lista[j];
				j--;
			}
			lista[j+1]=auxiliar;
		}
	}

	// Calcular el maximo de una lista
	public static int maximo(int [] lista){
		int maximo = 0;
		for (int i = 0; i < lista.length; i++){
			if (lista[i] > maximo)
				maximo = lista[i];
			
		}
		return maximo;
	}
	
	// Poner a cero todas las tiradas de un jugador
	public static void anularJugada(int jugador, int [][] tiradas){
		for (int j = 0; j < tiradas[jugador].length; j++){
			tiradas[jugador][j] = 0;
		}
	}

	// Imprimir todas las tiradas. Traza
	public static void imprimirTiradas(int [][] tiradas){
		System.out.println();
		for (int jug = 0; jug< tiradas.length; jug++){
			for(int dado = 0; dado< tiradas[jug].length ; dado++){
				System.out.print(tiradas[jug][dado]);
			}
			System.out.println();
		}
	}

	
	public static void main(String[] args) {
		int Njugadores = 3;
		int Ndados = 3;
		int Nrondas = 10;
		
		int [][] tiradas = new int[Njugadores][Ndados]; // resultados de las tiradas
		boolean [] ganadores = new boolean [Njugadores]; // ganadores de una ronda
		int [] rondasGanadas = new int [Njugadores]; // rondas ganadas por cada jugador
		
		
		// Inicializar rondas ganadas
		for (int jug = 0; jug < Njugadores; jug ++){
			rondasGanadas[jug] = 0;
		}
		
		// Determinar ganador
		int rondaActual = 0;
		int maximo;
		int dadoActual;
		int perdedores;
		int [] tiradasDado = new int[Njugadores]; // Tiradas de todos los jugadores para un dado
		
		while (rondaActual < Nrondas){
		
			// Inicializar ganadores ronda: todos a true
			for (int jug = 0; jug < Njugadores; jug ++){
				ganadores[jug] = true;
			}
			
			// Realizar jugadas
			for (int jug = 0; jug< Njugadores; jug++){
				for(int dado = 0; dado< Ndados; dado++){
					tiradas[jug][dado]= (int) (Math.random()*6) +1;
				}
			}
			
			// Traza
			imprimirTiradas(tiradas);
			
			// ordenar jugadas
			for (int jug = 0; jug< Njugadores; jug++){
				ordenar(tiradas[jug]);
			}
			
			// Traza
			imprimirTiradas(tiradas);

			// Determinar ganadores ronda
			dadoActual = Ndados-1; // Dado actual
			perdedores = 0; // Número de perdedores

			while (perdedores < Njugadores -1 && dadoActual >= 0){	
				for (int jug = 0; jug < Njugadores; jug++){
					tiradasDado[jug]= tiradas[jug][dadoActual];
				}
				maximo = maximo(tiradasDado);

				for (int jug = 0; jug < Njugadores; jug ++){
					if (ganadores[jug] && tiradas[jug][dadoActual]< maximo){
						ganadores[jug] = false;
						anularJugada(jug, tiradas);
						imprimirTiradas(tiradas);
						perdedores++;
					}	
				}
				
				dadoActual--;
			}
			//	Imprimir ganadores ronda y actualizar las rondas ganadas por jugador
			for (int jug = 0; jug < Njugadores; jug ++){
				if(ganadores[jug] == true){
					rondasGanadas[jug]++;
					System.out.println("Ganador ronda: " + rondaActual + " -> " + jug);
				}
			}
			
			rondaActual++;

			
		}
		
		// Imprimir 
		maximo = maximo(rondasGanadas);
		for (int jug = 0; jug < Njugadores; jug ++){
			if(rondasGanadas[jug] == maximo){
				System.out.println("\nJugador ganador (" + maximo+ " jugadas): " + jug);
			}
		}
	}
}
