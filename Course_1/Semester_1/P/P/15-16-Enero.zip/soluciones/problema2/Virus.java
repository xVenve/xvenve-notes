package enero15_16;

public class Virus {
	private String name;
	private String os;
	private int [] vulnerabilities;
	private boolean canBeCleaned;
	
	/** Constructor supposed to exist */
	public Virus (String n, String o, int [] v, boolean c){
		name = n;
		os = o;
		vulnerabilities = v;
		canBeCleaned = c;
	}
	
	//Get and set methods supposed to exist
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getOs() {
		return os;
	}

	public void setOs(String os) {
		this.os = os;
	}

	public int[] getVulnerabilities() {
		return vulnerabilities;
	}

	public void setVulnerabilities(int[] vulnerabilities) {
		this.vulnerabilities = vulnerabilities;
	}

	

	public boolean isCanBeCleaned() {
		return canBeCleaned;
	}

	public void setCanBeCleaned(boolean canBeCleaned) {
		this.canBeCleaned = canBeCleaned;
	}

	/** 
	 * Adds a new vulnerability to the list if it does not exist
	 * @param v the vulnerability code
	 * @return true if it has been added (it was new) and false if not (repeated vulnerability)
	 */
	public boolean addVulnerability (int v){
		//Checking it is new
		for (int ii=0; ii<vulnerabilities.length; ii++) {
			if (vulnerabilities[ii]==v)
				return false;
		}
		//If the program reaches here, v is new
		int [] aux = new int [vulnerabilities.length+1];
		System.arraycopy(vulnerabilities, 0, v, 0, vulnerabilities.length);
		aux[vulnerabilities.length] = v;
		vulnerabilities = aux;
		return true;
	}
	
	/**
	 * Returns if a virus exploits the vulnerability
	 * @param v the vulnerability
	 * @return true if the virus exploits it
	 */
	public boolean exploitsVulnerability (int v){
		for (int ii=0; ii<vulnerabilities.length; ii++) {
			if (v==vulnerabilities[ii])
				return true;
		}
		return false;
	}
	
	public String toString (){
		String res = "";
		res = res+ "Name: "+name+"\n";
		res = res + "Operating System: "+os+"\n";
		res = res + "Vulnerabilities: ";
		for (int ii=0; ii<vulnerabilities.length; ii++){
			res = res+" "+vulnerabilities[ii];
		}
		res += "\n" + "Can be cleaned: "+canBeCleaned;
		return res;
	}
	
	
}
