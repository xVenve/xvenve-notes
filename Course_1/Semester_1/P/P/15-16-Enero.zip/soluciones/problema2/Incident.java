package enero15_16;

public class Incident {
	private Virus virus;
	private Program program;
	private Client client;
	boolean confirmed;
	
	/**
	 * Sets the value of the confirmed field.  
	 * It checks that the client has the program, the program has a given vulnerability and the virus is able to exploit it 
	 */
	public void confirmIncident () {
		confirmed =  client.hasProgram(program.getName()) && (program.attackVector(virus) != null);
	}
	
	public Incident (Virus v, Program p, Client c){
		virus = v;
		program = p;
		client = c;
		confirmIncident();
	}
	
	public String toString (){
		String res = "Virus details: "+"\n"+virus.toString()+"\n";
		res += "Program details "+"\n"+program.toString()+"\n";
		res += "Confirmed: " +confirmed;
		return res;
	}
	
	
}
