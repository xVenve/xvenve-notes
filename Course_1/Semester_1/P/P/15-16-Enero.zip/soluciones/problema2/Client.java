package enero15_16;

public class Client {
	private String name;
	private Program [] programs;
	
	public boolean hasProgram (String program){
		for (int ii= 0; ii< programs.length; ii++) {
			if (programs[ii].getName().equals(program))
				return true;
		}
		return false;
	}
	
	public Client (String n, Program [] p){
		name = n;
		//It would be better to copy the array instead of assigning it
		programs = p;
	}
}
