package enero15_16;

public class Program {
	private String name;
	private String os;
	private int [] vulnerabilities;
	
	/**
	 * Returns if the program has the vulnerability
	 * @param v the vulnerability
	 * @return true if the program has it
	 */
	public boolean hasVulnerability (int v){
		for (int ii=0; ii<vulnerabilities.length; ii++) {
			if (v==vulnerabilities[ii])
				return true;
		}
		return false;
	}
	/**
	 * Returns an array with the list of vulnerabilities for this program this virus exploits
	 * @param v the virus
	 * @return the list of vulnerabilities for this program it exploits
	 */
	public int [] attackVector (Virus v){
		//Checking the OS
		if (!v.getOs().equals(os)) 
			return null;
		//The maximum size of the array is the # of vulnerabilities of the virus (or of the program)
		int [] aux = new int [v.getVulnerabilities().length];
		int foundV = 0;
		//For each virus vulnerability we look at the list of program vulnerabilities
		for (int ii=0; ii<v.getVulnerabilities().length; ii++){
			for (int jj=0; jj<vulnerabilities.length; jj++) {
				if (v.getVulnerabilities()[ii]==vulnerabilities[jj]) {
					aux[foundV] = vulnerabilities[jj];
					foundV++;
				}
			}
		}
		if (foundV == 0)
			return null;
		int res [] = new int [foundV];
		System.arraycopy(aux, 0, res, 0, foundV);
		return res;
	}
	
	//toString
	public String toString (){
		String res = "";
		res = res+ "Name: "+name+"\n";
		res = res + "Operating System: "+os+"\n";
		res = res + "Vulnerabilities: ";
		for (int ii=0; ii<vulnerabilities.length; ii++){
			res = res+" "+vulnerabilities[ii];
		}
		return res;
	}
	
	
	//Get and set methods and constructor
	public Program(String name, String o, int[] vulnerabilities) {
		this.name = name;
		os = o;
		this.vulnerabilities = vulnerabilities;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getOS() {
		return os;
	}


	public void setOS(String oS) {
		os = oS;
	}


	public int[] getVulnerabilities() {
		return vulnerabilities;
	}


	public void setVulnerabilities(int[] vulnerabilities) {
		this.vulnerabilities = vulnerabilities;
	}
	
	
}
