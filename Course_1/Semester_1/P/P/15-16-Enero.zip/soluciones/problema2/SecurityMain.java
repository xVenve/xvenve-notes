package enero15_16;

public class SecurityMain {

	public static void main(String[] args) {
		Program p1, p2, p3;
		Virus v;
		Client c1, c2;
		p1 = new Program ("Word","Windows", new int []{1,4,6});
		p2 = new Program ("Flash","Windows", new int []{3});
		p3 = new Program ("Java","Windows", new int []{4,8});
		
		v = new Virus("ILoveYou", "Windows", new int []{3,4}, false);
		
		c1 = new Client("Pepe", new Program [] {p1,p2});
		c2 = new Client("Juana", new Program []{p3});
		
		Incident i1, i2, i3;
		
		i1 = new Incident(v, p1, c1);
		i2 = new Incident(v, p2, c1);
		i3 = new Incident(v, p3, c2);
		
		i1.confirmIncident();
		i2.confirmIncident();
		i3.confirmIncident();
		
		Incident [] inc = new Incident[]{i1,i2,i3};
		for (int ii=0; ii<inc.length; ii++)
			System.out.println(inc[ii]);
		

	}

}
