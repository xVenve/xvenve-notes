package solucion;

import java.lang.Math;

public class Persona {
    private String identificador;
    private Ruta[] rutasRealizadas;
    private int contadorRutas;

    public Persona(String identificador) {
        this.identificador = identificador;
        this.rutasRealizadas = new Ruta[50];
        this.contadorRutas = 0;
    }

    public String getIdentificador() {
        return this.identificador;
    }

    public void addRuta(Ruta ruta) {
        if (contadorRutas<50) {
            this.rutasRealizadas[contadorRutas]= ruta;
            contadorRutas++;
        } else {
            System.out.println("Superado el numero de rutas posibles");
        }
        
    }

    public int calculaLongitudTotal() {
        int acumulador = 0;
        for(int i=0; i< contadorRutas; i++){
            acumulador += rutasRealizadas[i].getLongitud();
        }
        return acumulador;
    }

}