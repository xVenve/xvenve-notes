package solucion;

import java.lang.Math;
import java.util.Scanner;

public class Principal {

	
	public static void ordenarRutas(Ruta lista[]){
		Ruta variableauxiliar;
        //Usamos un bucle anidado
        for(int i=0;i<(lista.length-1);i++){
            for(int j=i+1;j<lista.length;j++){
                if(lista[i].getLongitud()>lista[j].getLongitud()){
                    //Intercambiamos valores
                	variableauxiliar=lista[i];
                    lista[i]=lista[j];
                    lista[j]=variableauxiliar;
 
                }
            }
        }
    }
    public static boolean existePunto(Ruta[] rutas, String punto) {
        for (Ruta rutaActual : rutas) {
            if (rutaActual.getInicio().equalsIgnoreCase(punto) || rutaActual.getFin().equalsIgnoreCase(punto)){
                // con uno que encuentre me basta
                return true;
            }
        }
        // si llego al final y no lo he encontrado
        return false;
    }

    public static boolean existeRutaCompuesta(Ruta[] rutas, String puntoA, String puntoB) {
        for (Ruta rutaInicial : rutas) {
            if (rutaInicial.getInicio().equalsIgnoreCase(puntoA) ){
                if(!rutaInicial.isCircular()){
                    for (Ruta rutaFinal : rutas) {
                        if (rutaFinal.getInicio().equalsIgnoreCase(rutaInicial.getFin()) && 
                        	rutaInicial.getFin().equalsIgnoreCase(puntoB)){
                        
                            return true;
                        }
                    }
                }
                
            }
        }
        // si llego al final y no lo he encontrado
        return false;
    }


    public static void main(String[] args) {
        String[] puntos = new String[40];
        for(int i=0;i<40; i++){
            puntos[i]= "Punto"+i;
        }

        Ruta[] rutas = new Ruta[12];
        for(int i=0;i<12; i++){
            String nombre = "Ruta"+i;
            String inicio = puntos[(((int)(Math.random()*40)))];
            String fin = puntos[(((int)(Math.random()*40)))]; 
            int numeroTramos = (((int)(Math.random()*30))+20);

            rutas[i]= new Ruta( nombre,  inicio,  fin,  numeroTramos);
        }

        Scanner teclado = new Scanner(System.in);

        String puntoA = "";
        do {
            System.out.println("Introduce el punto de inicio:");
            puntoA=teclado.next();
        } while (!existePunto(rutas, puntoA));
        
        String puntoB = "";
        do {
            System.out.println("Introduce el punto de fin:");
            puntoB=teclado.next();
        } while (!existePunto(rutas, puntoB));

        teclado.close();
        
        if (existeRutaCompuesta(rutas, puntoA,puntoB)){
            System.out.println("SI existe una ruta compuesta entre esos puntos");
        } else {
            System.out.println("NO existe una ruta compuesta entre esos puntos");
        }


        System.out.println("Rutas no circulares de mayor longitud:");
        ordenarRutas(rutas);

        int contador = 0;
        int indice = 0;
        while (contador < 4) {
            if(!rutas[indice].isCircular()){
                System.out.println( rutas[indice].getNombre());
                contador ++;
            }
           indice ++;
        }

        Persona[] personas = new Persona[20];
        for(int i=0;i<20; i++){
            String identificador = "Persona"+i;
            
            personas[i]= new Persona(identificador);

             for(int j=0;j<5; j++){
                 personas[i].addRuta(rutas[(((int)(Math.random()*12)))]);
             }
        }


        Persona personaMayorDistancia = personas[0];

        for(int i=0; i<personas.length;i++){
            if (personas[i].calculaLongitudTotal() > personaMayorDistancia.calculaLongitudTotal()){
                personaMayorDistancia = personas[i];
            }
        }

        System.out.println("La persona que más ha recorrido es: " + personaMayorDistancia.getIdentificador());


    }
}
