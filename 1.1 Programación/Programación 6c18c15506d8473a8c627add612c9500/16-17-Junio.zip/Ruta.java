package solucion;

import java.lang.Math;

public class Ruta {
    private String nombre;
    private int longitud;
    private String inicio;
    private String fin;
    private int[] tramos;

    public Ruta (String nombre, String inicio, String fin, int numeroTramos){
        this.nombre = nombre;
        this.inicio = inicio;
        this.fin = fin;

        longitud = 0;
        this.tramos = new int[numeroTramos];
        for(int i=0; i<numeroTramos; i++){
            tramos[i] = (((int)(Math.random()*200))+100);
            longitud += tramos[i];
        }
    }

    public String getInicio() {
        return this.inicio;
    }
    public String getFin() {
        return this.fin;
    }

    public String getNombre() {
        return this.nombre;
    }

    public int[] getTramos() {
        return this.tramos;
    }

    public int getLongitud() {
        return this.longitud;
    }

    public int calculaTramo(int metrosRecorridos){
        if (metrosRecorridos > longitud){
            return -1;
        } else{
        	int tramo= 0;
            int acumulador = 0;

            while (acumulador < metrosRecorridos) {
                acumulador += tramos[tramo];
                tramo ++;
            }

            return tramo;
        }
        
    }

    public boolean isCircular(){
        return this.inicio.equals(this.fin);
    }

    public int[] calculaTramosConsecutivosLargos(){
        int[] tramosLargos = new int[3];
        int longitudTramosLargos = 0;

        for(int i=0; i<tramos.length-3;i++){
            int longitudTramos = tramos[i]+tramos[i+1]+tramos[i+2];
            if (longitudTramos > longitudTramosLargos){
                tramosLargos[0]=tramos[i];
                tramosLargos[1]=tramos[i+1];
                tramosLargos[2]=tramos[i+2];
                longitudTramosLargos = longitudTramos;
            }
        }
        
        return tramosLargos;
    }
}
