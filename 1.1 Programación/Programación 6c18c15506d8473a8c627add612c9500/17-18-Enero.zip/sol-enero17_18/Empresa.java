package enero17_18;

public class Empresa {
	private Cliente [] clientes;
	private int numeroClientes = 0;
	
	Empresa(){
		this.clientes = new Cliente[100];
	}
	
	public void a�adirCliente(Cliente c) {
		clientes[numeroClientes] = c;
		numeroClientes++;
		
	}
	public void a�adirCompra(int id_cliente, int cuantía) {
		clientes[id_cliente].a�adirCompra(cuantía);
	}
	
	public void calcularOfertas() {
		for(int i = 0; i < numeroClientes; i++)
				clientes[i].calcularOferta();
	}
	
	public void imprimirOfertas() {
		for(int i = 0; i < numeroClientes; i++)
			clientes[i].imprimirOferta();
		
	}
	
	public static void main (String [] args) {
		Empresa empresa = new Empresa();
		int precio = 0;
		for (int i= 0; i < 100; i++) {
			empresa.a�adirCliente(new Cliente(i));
			for (int j= 0; j < 10; j++) {
					precio = (int) (Math.random()*200+1);
					empresa.a�adirCompra(i,precio); 
				}
		}
		empresa.calcularOfertas();
		empresa.imprimirOfertas();
	}
}