package enero17_18;
import java.util.Scanner;

public class JuegoReinas {
	
	private int [] posicionReinas;
	private int tama�oTablero;
	private int numeroReinasColocadas;
	
	// constructor
	JuegoReinas(int tama�o){
		posicionReinas = new int[tama�o];
		for (int i = 0; i < tama�o; i++)
			posicionReinas[i] = -1;
		this.tama�oTablero = tama�o;
		numeroReinasColocadas = 0;
	}
	
	// Método static que rellena una lista de booleans con un valor (true o false)
	public static void rellenarListaBoolean(boolean [] lista, boolean valor) {
		for (int i = 0; i < lista.length ; i++) 
			lista[i] = valor;
		
	}
	
	// Método static que comprueba si una lista de booleans tiene todos los elementos a true
	public static boolean esTodoTrue(boolean [] lista) {
		boolean todoTrue = true;
		int i = 0;
		while (todoTrue && i < lista.length) {
			todoTrue = todoTrue & lista[i];
			i++;
		}
		return todoTrue;

	}

	public void mostrarTablero() {
		for (int i = 0; i < tama�oTablero; i++) {
			for (int j = 0; j < tama�oTablero; j++ ) {
				if (posicionReinas[i] == j)
					System.out.print(" R ");
				else
					System.out.print(" - ");
			}
		System.out.println();	
		}
	}
	
	
	public boolean partidaGanada() {
		return tama�oTablero == numeroReinasColocadas;
	}
	
		
	private boolean [] calcularAmenazadas(int fila) {
		boolean [] columnasAmenazadas = new boolean[tama�oTablero];
		// Si hay una reina en la fila
		if (posicionReinas[fila] != -1)
			rellenarListaBoolean(columnasAmenazadas, true);
		else {
			rellenarListaBoolean(columnasAmenazadas, false);
			for (int i = 0; i < tama�oTablero; i++) {
				for (int j = 0; j < tama�oTablero; j++ ) {
					// Si hay una reina en  la columna j de una fila (i) 	
					if (posicionReinas[i] == j) {
						columnasAmenazadas[j] = true;
					}
					// Si hay una reina en la fila i cuya posición amenaza diagonalmente a la columna j de la fila 
					// que se recibe como argumento
					if (posicionReinas[i] != -1 && Math.abs(i-fila) == Math.abs(posicionReinas[i]-j))
						columnasAmenazadas[j] = true;
				}
			}
		}
		return columnasAmenazadas;
	}
	
	public void mostrarNOAmenazadas() {
		boolean [] columnasAmenazadas;
		
		for (int i = 0; i < tama�oTablero; i++) {
			System.out.print("\nFILA: " + i);
			System.out.print(", COLUMNAS NO AMENAZADAS: ");
			columnasAmenazadas = calcularAmenazadas(i);
			boolean todasAmenazadas = esTodoTrue(columnasAmenazadas);
			if (!todasAmenazadas) {
				for (int j = 0; j < tama�oTablero; j++) {
					if (!columnasAmenazadas[j])
						System.out.print(" " + j);
					}
				}
			}
		System.out.println();
	}

	public boolean finPartida() {
		boolean [] columnasAmenazadas;
		
		for (int i = 0; i < tama�oTablero; i++) {
			columnasAmenazadas = calcularAmenazadas(i);
			boolean todasAmenazadas = esTodoTrue(columnasAmenazadas) ;
			// Si existe alguna fila sin reina con todas las columnas amenazadas
			if (todasAmenazadas && posicionReinas[i] == -1)
				return true;
		}
	if (partidaGanada())
		return true;
	return false;
	
	}
		
	public boolean situarReina(int fila, int columna) {
		if (fila >= 0 && fila < tama�oTablero && columna >=0 && columna < tama�oTablero) {
			boolean [] columnasAmenazadas;
			columnasAmenazadas = calcularAmenazadas(fila);
			if (!columnasAmenazadas[columna]) {
				posicionReinas[fila] = columna;
				numeroReinasColocadas++;
				return true;
			}
		}
		return false;
	}
	
	
	public static void main (String [] args) {
 
		
		Scanner sc = new Scanner(System.in);
		JuegoReinas juego = new JuegoReinas(4);
		boolean situada;
		juego.mostrarTablero();
		juego.mostrarNOAmenazadas();
		do {
			System.out.println("Introduzca fila de la reina a situar:");
			int fila = sc.nextInt();
			System.out.println("Introduzca columna de la reina a situar:");
			int columna = sc.nextInt();
			situada = juego.situarReina(fila, columna);
			if (!situada)
				System.out.println("No se ha podido situar la reina solicitada");
			juego.mostrarTablero();
			juego.mostrarNOAmenazadas();
			
		}
		while (!juego.finPartida()); 

		if (juego.partidaGanada())
			System.out.println("GANASTE!!");
		else 
			System.out.println("PERDISTE!!");
		System.out.println("Game over");
		sc.close();

			
		
	}
	
	
	
	

}
