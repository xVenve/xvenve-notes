package enero17_18;

public class Cliente {
	private int idCliente;
	private int [] compras;
	private int numeroCompras = 0;
	private boolean enviarOferta;
	
	Cliente(int idCliente){
		this.idCliente = idCliente;
		compras = new int [10];
		numeroCompras = 0;
	}
	
	public void a�adirCompra(int cuantía) {
		compras[numeroCompras] = cuantía;
		numeroCompras++;
		
		}
	
	public void calcularOferta() {
		int totalConsecutivas = 0;
		int i = 0;
		while (totalConsecutivas < 500 && i <= numeroCompras-3) {
			totalConsecutivas = compras[i] + compras[i+1] + compras[i+2];
			i++;
		}
		enviarOferta = totalConsecutivas >500;
	}
	
	public void imprimirOferta() {
		if (enviarOferta)
			System.out.println("Enviar oferta a cliente: " + idCliente);
	
	}
}
 