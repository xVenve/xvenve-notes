package Semana4;

public class Ejercicio2 {

	public static void main(String[] args) {
		
		int a = 23;
		byte b = (byte)a;//SI
		short s = (short)a;//SI
		long c=(long)a;//SI
		float d=(float)a;//SI
		double e=(double)a;//SI
		char f=(char)a;//SI
		boolean g=(boolean)a;//NO
		String h=(String)a;//NO
		
		byte aa = (byte)23;
		int bb = (int)aa;//SI
		short ss = (short)aa;//SI
		long cc=(long)aa;//SI
		float dd=(float)aa;//SI
		double ee=(double)aa;//SI
		char ff=(char)aa;//SI
		boolean gg=(boolean)aa;//NO
		String hh=(String) aa;//NO
		
		short a3 = 23;
		byte s3 = (byte)a3;//SI
		int b3 = (long)a3;//NO
		long c3=(long)a3;//SI
		float d3=(float)a3;//SI
		double e3=(double)a3;//SI
		char f3=(char)a3;//SI
		boolean g3=(boolean)a3;//NO
		String h3=(String)a3;//NO
		
		long a4=23;
		byte c4 = (byte)a4;//SI
		int b4 = (int)a4;//SI
		short s4 = (short)a4;//SI
		float d4=(float)a4;//SI
		double e4=(double)a4;//SI
		char f4=(char)a4;//SI
		boolean g4=(boolean)a4;//NO
		String h4=(String)a4;//NO
		
		float a5=23f;
		byte d5 = (byte)a5;//SI
		int b5 = (int)a5;//SI
		short s5 = (short)a5;//SI
		long c5=(long)a5;//SI
		double e5=(double)a5;//SI
		char f5=(char)a5;//SI
		boolean g5=(boolean)a5;//NO
		String h5=a5;//NO
		
		double a6=23;
		byte e6 = (byte)a6;//SI
		int b6 = (int)a6;//SI
		short s6 = (short)a6;//SI
		long c6=(long)a6;//SI
		float d6=(float)a6;//SI
		char f6=a6;//SI
		boolean g6=(boolean)a6;//NO
		String h6=(String)a6;//NO
		
		char a7='a';
		byte f7 = (byte)a7;//SI
		int b7 = (int)a7;//SI
		short s7 = (short)a7;//SI
		long c7=(long)a7;//SI
		float d7=(float)a7;//SI
		double e7=(double)a7;//SI
		boolean g7=(boolean)a7;//NO
		String h7=(String)a7;//NO
		
		boolean a8=true;
		byte g8 = (byte)a8;//NO
		int b8 = (int)a8;//NO
		short s8 = (short)a8;//NO
		long c8=(long)a8;//NO
		float d8=(float)a8;//NO
		double e8=(double)a8;//NO
		char f8=(char)a8;//NO
		String h8=(String)a8;//NO
		
		String a9="aa";
		byte h9 = (byte)a9;//NO
		int b9 = (int)a9;//NO
		short s9 = (short)a9;//NO
		long c9=(long)a9;//NO
		float d9=(float)a9;//NO
		double e9=(double)a9;//NO
		char f9=(char)a9;//NO
		boolean g9=(boolean)a9;//NO
		
		//Siguen quedando casillas con NO, porque hay variables que no son compatibles
		//como las variables numéricas y los tipos boolean, String, etc.

		

	}

}
