package Semana4;

public class Ejercicio2 {

	public static void main(String[] args) {
		
		int a = 23;
		byte b = a;//NO
		short s = a;//NO
		long c=a;//SI
		float d=a;//SI
		double e=a;//SI
		char f=a;//NO
		boolean g=a;//NO
		String h=a;//NO
		
		byte aa = 23;
		int bb = aa;//SI
		short ss = aa;//SI
		long cc=aa;//SI
		float dd=aa;//SI
		double ee=aa;//SI
		char ff=aa;//NO
		boolean gg=aa;//NO
		String hh=aa;//NO
		
		short a3 = 23;
		byte s3 = a3;//NO
		int b3 = a3;//SI
		long c3=a3;//SI
		float d3=a3;//SI
		double e3=a3;//SI
		char f3=a3;//NO
		boolean g3=a3;//NO
		String h3=a3;//NO
		
		long a4=23;
		byte c4 = a4;//NO
		int b4 = a4;//NO
		short s4 = a4;//NO
		float d4=a4;//SI
		double e4=a4;//SI
		char f4=a4;//NO
		boolean g4=a4;//NO
		String h4=a4;//NO
		
		float a5=23f;
		byte d5 = a5;//NO
		int b5 = a5;//NO
		short s5 = a5;//NO
		long c5=a5;//NO
		double e5=a5;//SI
		char f5=a5;//NO
		boolean g5=a5;//NO
		String h5=a5;//NO
		
		double a6=23;
		byte e6 = a6;//NO
		int b6 = a6;//NO
		short s6 = a6;//NO
		long c6=a6;//NO
		float d6=a6;//NO
		char f6=a6;//NO
		boolean g6=a6;//NO
		String h6=a6;//NO
		
		char a7='a';
		byte f7 = a7;//NO
		int b7 = a7;//SI
		short s7 = a7;//NO
		long c7=a7;//SI
		float d7=a7;//SI
		double e7=a7;//SI
		boolean g7=a7;//NO
		String h7=a7;//NO
		
		boolean a8=true;
		byte g8 = a8;//NO
		int b8 = a8;//NO
		short s8 = a8;//NO
		long c8=a8;//NO
		float d8=a8;//NO
		double e8=a8;//NO
		char f8=a8;//NO
		String h8=a8;//NO
		
		String a9="aa";
		byte h9 = a9;//NO
		int b9 = a9;//NO
		short s9 = a9;//NO
		long c9=a9;//NO
		float d9=a9;//NO
		double e9=a9;//NO
		char f9=a9;//NO
		boolean g9=a9;//NO
		
		//Si asignamos un literal a una variable de tipo float, dará el mismo
		//error que en el ejercicio anterior al intentar transformarlo a double.
		

	}

}
