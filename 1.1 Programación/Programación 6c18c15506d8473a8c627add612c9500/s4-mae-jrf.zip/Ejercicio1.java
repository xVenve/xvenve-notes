package Semana4;

public class Ejercicio1 {
	public static void main(String[] args) {
		
		byte myByte = 125;
		System.out.println(myByte);
		short myShort = 32342;
		System.out.println(myShort);
		char myChar = 97;
		System.out.println(myChar);
		float myFloat = 3.0;
		System.out.println(myFloat);
		//Da error porque no se puede convertir una variable de tipo double a tipo float.
		//Porque al declarar la variable myFloat de tipo float asignandole el valor 3.0 
		//sin la "f" de coma flotante, la intenta transformar a tipo double y da error.

	}

}
