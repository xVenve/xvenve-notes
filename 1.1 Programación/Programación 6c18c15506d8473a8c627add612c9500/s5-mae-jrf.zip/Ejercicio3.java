package Semana5;
import java.util.Scanner;

public class Ejercicio3 {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Introduzca dos nombres con un n�mero cada uno.");
		String a=sc.next();
		int an=sc.nextInt();
		String b=sc.next();
		int bn=sc.nextInt();
		
		if(an<bn) {
			System.out.println(b +" es mayor que " + a);
		}else if(an>bn) {
			System.out.println(a +" es mayor que " + b);
		}else {
			System.out.println(b +" y "+ a +" tienen la misma edad.");
		}
			
	}

}
