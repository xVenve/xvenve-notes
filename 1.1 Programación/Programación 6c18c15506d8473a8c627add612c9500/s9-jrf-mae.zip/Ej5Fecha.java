package Semana9;
public class Ej5Fecha {
	public int dia, anio;
	String mes="Noviembre";
	public Ej5Fecha(int dia, int anio) {
		this.anio = anio;
		this.dia = dia;
	}
	
}
