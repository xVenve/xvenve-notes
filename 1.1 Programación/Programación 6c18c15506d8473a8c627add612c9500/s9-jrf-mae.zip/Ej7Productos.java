package Semana9;public class Ej7Productos {
	public String nombre;
	public float precio;
	public int stock;
	public Ej7Productos() {
		
	}
	public Ej7Productos(String nombre, float precio, int stock) {
		this.nombre = nombre;
		this.precio = precio;
		this.stock = stock;
	}
}
