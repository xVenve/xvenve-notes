package Semana9;
public class Ej5Asignatura {
	public String nombre;
	public String cuatrimestre;
	public Ej5Fecha[] fecha;
	public Ej5Asignatura(String nombre, String cuatrimestre) {
		this.nombre = nombre;
		this.cuatrimestre = cuatrimestre;
	}
}
