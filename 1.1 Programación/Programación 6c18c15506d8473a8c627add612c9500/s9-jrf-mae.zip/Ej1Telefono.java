package Semana9;

public class Ej1Telefono {
	public String marca;
	public String modelo;
	public int anio;
}
