package Semana9;
public class Ej7Array {
	public Ej7Productos[] Productos;
}
