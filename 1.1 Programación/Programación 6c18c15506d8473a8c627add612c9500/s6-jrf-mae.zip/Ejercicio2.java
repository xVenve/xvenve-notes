package Semana6;

public class Ejercicio2 {
	public static void main(String[] args) {

		for(double n=1; n<=100; n+=1.5) {
			System.out.print(n);
			if(n!=100) {
				System.out.print(", ");

			}			
			
		}
		
	}

}
