package Semana3;

public class Ejercicio3 {
	public static void main(String[] arg) {
		int a=8;
		a=6;
		//Es posible cambiar el valor de una varible siempre que no este precedida del elemento "final".
		System.out.print(a);
	}

}
