package Semana3;

public class Ejercicio12 {
	public static void main(String[] arg) {
		byte a=1,b=2,c;
		short d=3,e=4,f;
		int g=5,h=6,i;
		long j=7,k=8,l;
		char m='a',n='b',o;
		
		/*
		c=a+b;
		System.out.println(c);
		c=a-b;
		System.out.println(c);
		c=a*b;
		System.out.println(c);
		c=a/b;
		System.out.println(c);

		f=d+e;
		System.out.println(f);
		f=d-e;
		System.out.println(f);
		f=d*e;
		System.out.println(f);
		f=d/e;
		System.out.println(f);
		*/
		
		i=g+h;
		System.out.println(i);
		i=g-h;
		System.out.println(i);
		i=g*h;
		System.out.println(i);
		i=g/h;
		System.out.println(i);

		l=j+k;
		System.out.println(l);
		l=j-k;
		System.out.println(l);
		l=j*k;
		System.out.println(l);
		l=j/k;
		System.out.println(l);
		
		/*
		o=m+n;
		System.out.println(o);
		o=m-n;
		System.out.println(o);
		o=m*n;
		System.out.println(o);
		o=m/n;
		System.out.println(o);
		*/
		
		/*
		 * Se produce error al operar con variables más pequeñas que int, también salta error con char,
		 *ya que son caracteres y no se puede operar con ellos.
		 */
		
	}

}
