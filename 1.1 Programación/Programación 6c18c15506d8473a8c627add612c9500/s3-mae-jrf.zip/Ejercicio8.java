package Semana3;

public class Ejercicio8 {
	public static void main(String[] arg) {
		
		int a;
		int a;
		//No es posible, porque no puedes nombrar igual a dos varibles.
		
		char a;
		//Por la misma razón que antes no funciona.
	}
	

}
