package Semana3;

public class Ejercicio13 {
	public static void main(String[] arg) {
		int a=5,b=0,c;
		c=a/b;
		System.out.print(c);
		/* 
		 *Se produce un fallo, ya que no es posible dividir entre 0, el error es independiente del tipo de varible
		 *es una imposibilidad matemática. 
		 */
	}
}
