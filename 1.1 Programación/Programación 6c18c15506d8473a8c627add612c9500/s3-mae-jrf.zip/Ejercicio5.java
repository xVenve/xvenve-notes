package Semana3;

public class Ejercicio5 {
	public static void main(String[] arg){
		byte a=128;
		short b=32768;
		int c=2147483648;
		long d=9223372036854775808L;
		float e=3.40282347E+39F;
		double f=1.79769313486231570E+309;
		
		//Los valores de la variables se salen del rango de las varibles, por lo que no los pueden almacenar.
	}

}
