package Semana3;

public class Ejercicio6 {
	public static void main(String[] arg) {
		float a=1234567890.0F;
		float b=1234567899.0F;
		System.out.println(a-b);
		//El resultado es 0.0
		
		int c=7;
		int d=5;
		System.out.print(d-c);
		//El resultado es -2, un nuemero entero como 5 y 7
		
	}

}
