package Semana3;

public class Ejercicio2 {
	public static void main(String[]arg) {
		String a;
		System.out.println(a);
		/*
		 * El programa no funciona, porque al intentar imprimir por pantalla 
		 * el contenido de la variable "a" no encuentra ningún valor.
		 */
		String b=a;
		/*
		 * El programa sigue sin funcionar, porque como ocurría antes no puedes darle a la nueva varible "b"
		 * el valor de la variable "a", que sigue sin tener ningún valor asignado.
		 */
		
	}

}
