package Semana3;

public class Ejercicio1 {
	public static void main(String[] arg) {
		char a='j';
		byte b=1;
		short c=2;
		int  d=3;
		long e=4;
		float f=3.5F;
		double g=5.6;
		boolean h=true;
		String i="Hello";
		
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
		System.out.println(e);
		System.out.println(f);
		System.out.println(g);
		System.out.println(h);
		System.out.println(i);
	}

}
