package Semana3;

public class Ejercicio7 {
	public static void main(String[] arg){
		int a,b,c;
		a=1;
		b=2;
		c=3;
		
		int d=4,f,e=5;
		f=6;
	}

}
