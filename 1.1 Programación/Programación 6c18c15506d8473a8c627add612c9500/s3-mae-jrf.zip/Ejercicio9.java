package Semana3;

public class Ejercicio9 {
	public static void main(String[] arg) {
		char b='hola';
		//No se puede, porque el tipo char solo tiene espacio para un caracter.
		String a="hola";
		//Si se puede, ya que el tipo String permite almacenar una linea de caracteres.
	}
}
