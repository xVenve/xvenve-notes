package Semana10;

public class Ej2Isla {
	public String nombre;
	public float lat;
	public float alt;
	public String pais;
	public boolean habitada=true;
	
	public Ej2Isla(String nombre, float lat, float alt, String pais) {
		this.nombre = nombre;
		this.lat = lat;
		this.alt = alt;
		this.pais = pais;
	}
}
