package Semana10;

public class Ej2Pasajero {
	public String nombre;
	public String apellidos;
	public String iden;
	public String billete;
	
	public Ej2Pasajero(String nombre, String apellidos, String iden, String billete) {
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.iden = iden;
		this.billete = billete;
	}
	
}
