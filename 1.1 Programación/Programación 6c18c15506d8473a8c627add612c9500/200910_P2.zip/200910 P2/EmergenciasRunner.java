
public class EmergenciasRunner {

	public static void main(String[] args) {
		
		//Creo una unidad de emergencias con un max de 10 coches y 5 ambulancias 

		UnidadEmergencias miUnidaddeEmergencias = new UnidadEmergencias(10,5);

		//Test coches
		miUnidaddeEmergencias.altaCoche("0001AAA");
		miUnidaddeEmergencias.altaCoche("0002AAA");
		miUnidaddeEmergencias.altaCoche("0003AAA");
		miUnidaddeEmergencias.censoCoches();	
		miUnidaddeEmergencias.bajaCoche("0002AAA");
		miUnidaddeEmergencias.altaCoche("0004AAA");
		miUnidaddeEmergencias.censoCoches();	
		
		//Test ambulancias
		miUnidaddeEmergencias.altaAmbulancia("0001BBB",1);
		miUnidaddeEmergencias.altaAmbulancia("0002BBB",1);
		miUnidaddeEmergencias.censoAmbulancias();	
		miUnidaddeEmergencias.bajaAmbulancia("0001BBB");
		miUnidaddeEmergencias.altaAmbulancia("0003BBB",2);
		miUnidaddeEmergencias.censoAmbulancias();	
					
		//Test plantilla
		miUnidaddeEmergencias.getLaPlantilla().anyadirEmpleado("Medico", "00000001A");
		miUnidaddeEmergencias.getLaPlantilla().anyadirEmpleado("Enfermero", "00000001B");
		miUnidaddeEmergencias.getLaPlantilla().anyadirEmpleado("Conductor", "00000001C");
		miUnidaddeEmergencias.getLaPlantilla().anyadirEmpleado("Enfermero", "00000002B");		
		miUnidaddeEmergencias.getLaPlantilla().censoEmpleados();
		miUnidaddeEmergencias.getLaPlantilla().eliminarEmpleado("00000002B");
		miUnidaddeEmergencias.getLaPlantilla().censoEmpleados();

		//Test habilidades
		new Medico("00000099A").receta();
		new Conductor("00000099C").conduceVehiculo();
		
		//Test fundaci�n
		UnidadEmergencias  miUnidaddeEmergencias2 = new UnidadEmergencias(5,2);
		
	}
}
