package Semana3;

public class SNode {

	public Book elem;
	public SNode next;
	
	public SNode(Book newElem) {
		elem = newElem;
	}
	
}

