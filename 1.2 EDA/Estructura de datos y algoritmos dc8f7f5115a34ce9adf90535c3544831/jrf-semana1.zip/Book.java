package Semana1;

public class Book {
	public String title;
	public String author;
	public int gender;
	
	public Book(String ti, String au, int ge) {
		title=ti;
		author=au;
		gender=ge;
	}
}
