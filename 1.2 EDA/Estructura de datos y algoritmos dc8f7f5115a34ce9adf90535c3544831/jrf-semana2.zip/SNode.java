package Semana2;

public class SNode {

	public Character elem;
	public SNode next;
	
	public SNode(Character e) {
		elem = e;
	}
	
}

