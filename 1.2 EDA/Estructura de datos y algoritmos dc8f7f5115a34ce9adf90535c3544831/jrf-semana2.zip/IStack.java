package Semana2;

public interface IStack {

	public boolean isEmpty();
	public void push(Character elem);
	public Character pop();
	public Character top();
	public int getSize();

}



