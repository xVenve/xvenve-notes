package Semana4;

public class DNode {

	public Book elem;
	public DNode prev;
	public DNode next;
	
	public DNode(Book elem) {
		this.elem = elem;
	}

}

