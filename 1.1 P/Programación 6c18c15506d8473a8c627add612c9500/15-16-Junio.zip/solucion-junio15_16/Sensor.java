package junio15_16;


public class Sensor {
	private float temp[];
	private float humidity;
	private String location;
	private String id;
	//An internal field to store the number of full positions of the 
	//temperatures array
	private int taken;
	
	/**
	 * No-argument constructor
	 */
	public Sensor(){
		temp = new float[24];
		humidity = 0.0f;
		location = "Unknown";
		id = "LEG00";
		taken = 0;
	}
	
	/**
	 * Full constructor. Problem says nothing about what to receive as temperature.
	 * So we decided to receive the first position of the array. Any other alternative is
	 * also valid
	 * @param t the last temperature measured
	 * @param h the humidity
	 * @param s the location
	 * @param i the id
	 */
	public Sensor(float t, float h, String s, String i){
		temp = new float[24];
		temp[0] = t;
		setHumidity(h);
		location = s;
		taken = 1;
		id = i;
	}
	
	public float getHumidity() {
		return humidity;
	}

	public void setHumidity(float hum) {
		if (hum > 100.0)
			humidity = 100;
		else if (hum < 0.0)
			humidity = 0;
		else
			humidity = hum;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String loc) {
		this.location = loc;
	}

	/**
	 * Stores the new measure in the array, moving all one position to the end
	 * @param newf
	 */
	public void storeMeasure(float newf){
		for (int ii = temp.length-1; ii > 0; ii--){
			temp[ii] = temp[ii-1]; 
		}
		temp[0] = newf;
		//Updating the number of full positions
		if (taken < temp.length)
			taken++;
	}
			

	public boolean alarm (float limT, float limH){
		//Checking first the humidity as it is easier
		if (humidity<limH)
			return true;
		//Now checking the temperature
		int signalT = 0;
		for (int ii =0; ii< taken; ii++){
			if (temp[ii] > limT){
				signalT++;
			}
		}
		//We use floats to do the calculation more accurate
		float freq = (float) signalT/ taken;
		if (freq > 1.0/3)
			return true;
		else
			return false;
	}
	
	public void calibrate (Sensor another){
		for (int i=0; i< temp.length; i++){
			temp[i] = another.temp[i];
		}
		humidity = another.humidity;
	}
	
	
	public float meanTemperature(){
		float mt =0;
		for (int ii=0; ii< taken; ii++){
			mt += temp[ii];
		}
		return mt/taken;
	}
	
	public String toString(){
		String s = "Sensor id: "+id+"\nLocation: "+location+"\nLast temperature reading: "
				+ temp[0] + " degrees\t24H mean temp.: "+ meanTemperature() +" degrees \nRelative Humidity: " + humidity+"%";
		return s;
	}
}
