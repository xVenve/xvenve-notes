package junio15_16;


public class ControlCenter {
	public static void main(String[] args) {
		Sensor master = new Sensor(32.3F, 25, "Madrid", "MA00");
		Sensor sensors[] = new Sensor[20];

		for (int ii = 0; ii < sensors.length; ii++){
			float rTemp =  (float) (Math.random() * 10) + 30;
			sensors[ii] = new Sensor(rTemp, 45.0f, "Unknown", "UKN00"+ii);
		}

		sensors[sensors.length-1].calibrate(master);

		for (int ii = 0; ii < sensors.length; ii++){
			if (sensors[ii].alarm(35.0F, 30.0F))
				System.out.println(sensors[ii]);
		}

	}
}
