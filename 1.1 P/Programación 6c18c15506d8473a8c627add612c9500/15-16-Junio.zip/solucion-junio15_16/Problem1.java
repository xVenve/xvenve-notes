package junio15_16;

import java.util.Scanner;


public class Problem1 {

	
	/**
	 * Prints the array on the screen, marking the positions where the minimum lies
	 * @param arr The array
	 * @param occur A boolean array (equal length as arr). True elements mark the positions
	 * of the minimum.
	 */
	public static void showArray(int arr[], boolean occur[]){
		for (int ii =0; ii< arr.length; ii++){
			if (!occur[ii])
				System.out.print(arr[ii]+ " ");
			else
				System.out.print("<<"+ arr[ii]+ ">> ");
		}
		System.out.println();
	}
	
	/**
	 * Returns the maximum of an array
	 * @param arr the array
	 * @return	the maximum
	 */
	public static int max(int arr[]){
		int m = arr[0];
		for (int ii=0; ii< arr.length; ii++){
			if (arr[ii]> m)
				m = arr[ii];
		}
			
		return m;
	}
	
	/**
	 * Finds the positions of the minimum in an array and returns them
	 * @param arr the array
	 * @return a boolean array (equal length as arr). True elements mark the positions
	 * of the minimum.
	 */
	public static boolean[] minPositions (int arr[]){
		int min = arr[0];
		boolean minPos [] = new boolean[arr.length];
		//First loop, calculating the minimum
		for (int ii=1; ii< arr.length; ii++){
			if (arr[ii] < min){
				min = arr[ii];
			}
		}
		//Second loop, looking for the positions of the minimum
		for (int ii=0; ii< arr.length; ii++){
			if (arr[ii] == min){
				minPos[ii] = true;
			}
		}
		return minPos;
	}
	
	/**
	 * Generates a random array of int in the range 0 to 19
	 * @param size The size of the array
	 * @return a random array
	 */
	public static int[] randomArray(int size){
		int a[] = new int[size];
		for (int ii= 0; ii<size ; ii++){
			a[ii] = (int)(Math.random() * 20);
		}
		return a;
	}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Size of the array?");
		int size = sc.nextInt();
		System.out.println("Maximum number of times?");
		int execs = sc.nextInt();
		int array[];
		int mincounts[] = new int[size];
		boolean ocurmin[];
		int attempts = 0;
		int maxmin = 0;
		
		while (maxmin < execs && attempts < 100){
			array = randomArray(size);
			ocurmin = minPositions(array);
			showArray(array, ocurmin);
			//Adding 1 to the positions where the minimum is
			for (int jj = 0; jj< ocurmin.length; jj++){
				if (ocurmin[jj])
					mincounts[jj]++;
			}	
			maxmin = max(mincounts);
			attempts++;
		}
		
		System.out.println("Frequency of the minimum");
		for (int i = 0; i< size; i++){
			System.out.println("Pos " + i + ":" + mincounts[i]);
		}
		
		if ((2 *(attempts/size)) < maxmin){
			System.out.println("PROBLEMATIC SEQUENCE");
		}
		sc.close();
	}
}